import { createFileRoute } from "@tanstack/react-router";
import {
  Flame, LayoutDashboard, Map, LineChart, FileText, Users, Link2, Database, BarChart3, Settings,
  Search, Calendar, Bell, Home, FileCheck, Shield, Plus, Minus, Crosshair, CloudSun, CheckCircle2,
} from "lucide-react";
import mapImg from "@/assets/map.jpg";
import fireImg from "@/assets/fire.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FireChain AI — Dashboard Kebakaran Hutan" },
      { name: "description", content: "Pantau titik panas, risiko, dan laporan kebakaran hutan Kalimantan secara real-time." },
      { property: "og:title", content: "FireChain AI — Dashboard Kebakaran Hutan" },
      { property: "og:description", content: "Deteksi, verifikasi, dan respons kebakaran hutan dengan AI & blockchain." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const nav = [
  [LayoutDashboard, "Dashboard"], [Map, "Live Map"], [LineChart, "Analisis Risiko"], [FileText, "Laporan Kejadian"],
  [Users, "Respons Lapangan"], [Link2, "Blockchain Audit"], [Database, "Data & API"], [BarChart3, "Laporan & Statistik"], [Settings, "Pengaturan"],
] as const;

const kpis = [
  { icon: Flame, label: "Titik Panas Aktif", value: "342", delta: "↑ 12% dari kemarin", cls: "from-primary/40 text-primary" },
  { icon: Home, label: "Area Risiko Tinggi", value: "12,480 ha", delta: "↑ 29%", cls: "from-accent/40 text-accent" },
  { icon: FileCheck, label: "Laporan Masuk", value: "128", delta: "↑ 48%", cls: "from-success/40 text-success" },
  { icon: Shield, label: "Respons Berlangsung", value: "18", delta: "↑ 6 tim aktif", cls: "from-info/40 text-info" },
];

const reports: [string,string,string,string,string][] = [
  ["FC-2026-0018", "Kebakaran Terdeteksi", "Kalimantan Tengah", "Tinggi", "2 menit lalu"],
  ["FC-2026-0017", "Asap Terlihat", "Kalimantan Barat", "Sedang", "15 menit lalu"],
  ["FC-2026-0016", "Hotspot Satelit", "Kalimantan Timur", "Sedang", "32 menit lalu"],
  ["FC-2026-0015", "Laporan Masyarakat", "Kalimantan Tengah", "Rendah", "1 jam lalu"],
];
const badge: Record<string, string> = {
  Tinggi: "bg-primary/20 text-primary", Sedang: "bg-accent/20 text-accent", Rendah: "bg-success/20 text-success",
};

const factors = [["Hotspot Satelit", 92], ["Kondisi Cuaca Kering", 78], ["Lahan Gambut", 85], ["Kedekatan Permukiman", 64], ["Riwayat Kebakaran", 71]] as const;
const chain = [["Laporan Dibuat", "14:32", "0x7a3...e9f1"], ["Dalam Verifikasi", "14:45", "0x8b2...4c1d"], ["Terverifikasi", "15:10", "0x4f9...7a2e"], ["Respons Dimulai", "16:20", "0x1c8...9d3a"]];
const emissions = [20, 25, 35, 40, 50, 60, 70, 85, 65];

function Index() {
  return (
    <div className="flex min-h-screen bg-background text-foreground">
      <aside className="hidden w-60 shrink-0 flex-col border-r border-sidebar-border bg-sidebar p-4 lg:flex">
        <div className="mb-8 flex items-center gap-2 text-xl font-extrabold">
          <Flame className="h-7 w-7 text-primary" /> FireChain <span className="text-primary">AI</span>
        </div>
        <nav className="space-y-1">
          {nav.map(([Icon, label], i) => (
            <a key={label} href="#" className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm ${i === 0 ? "bg-primary text-primary-foreground glow" : "text-sidebar-foreground hover:bg-sidebar-accent"}`}>
              <Icon className="h-4 w-4" /> {label}
            </a>
          ))}
        </nav>
        <div className="panel mt-auto p-3">
          <p className="font-semibold">FireChain AI</p>
          <p className="text-xs text-muted-foreground">Detect • Verify • Respond</p>
        </div>
      </aside>

      <main className="flex-1 space-y-4 p-4">
        <header className="flex flex-wrap items-center gap-3">
          <div className="panel flex flex-1 items-center gap-2 px-3 py-2 text-sm text-muted-foreground">
            <Search className="h-4 w-4" /> Cari lokasi, koordinat, atau laporan...
          </div>
          <div className="panel flex items-center gap-2 px-3 py-2 text-sm"><Calendar className="h-4 w-4" /> 1 Sep 2026 - 30 Sep 2026</div>
          <Bell className="h-5 w-5" />
          <div className="text-sm"><p className="font-semibold">Admin</p><p className="text-xs text-muted-foreground">Operator</p></div>
        </header>

        <section className="grid grid-cols-2 gap-4 xl:grid-cols-4">
          {kpis.map((k) => (
            <div key={k.label} className={`panel flex items-center gap-4 bg-gradient-to-br to-card p-4 ${k.cls}`}>
              <k.icon className="h-10 w-10" />
              <div>
                <p className="text-xs text-foreground">{k.label}</p>
                <p className="text-2xl font-bold text-foreground">{k.value}</p>
                <p className="text-xs">{k.delta}</p>
              </div>
            </div>
          ))}
        </section>

        <section className="grid gap-4 xl:grid-cols-[1fr_320px]">
          <div className="panel relative overflow-hidden">
            <img src={mapImg} alt="Peta titik panas Kalimantan" width={1280} height={832} className="h-full min-h-[420px] w-full object-cover" />
            <div className="absolute left-3 top-3 flex flex-col gap-2">
              {[Plus, Minus, Crosshair].map((I, i) => <button key={i} className="panel p-2"><I className="h-4 w-4" /></button>)}
            </div>
            <div className="absolute right-3 top-3 w-52 space-y-3">
              <div className="panel space-y-2 bg-card/90 p-3 text-xs">
                <p className="text-sm font-semibold">Layer Peta</p>
                {["Titik Panas (NASA FIRMS)", "Risiko Kebakaran (AI)", "Lahan Gambut", "Batas Administrasi", "Cuaca (BMKG)"].map((l) => (
                  <label key={l} className="flex items-center gap-2"><input type="checkbox" defaultChecked className="accent-info" /> {l}</label>
                ))}
              </div>
              <div className="panel space-y-2 bg-card/90 p-3 text-xs">
                <p className="text-sm font-semibold">Tingkat Risiko</p>
                {[["Sangat Tinggi", "bg-primary"], ["Tinggi", "bg-accent"], ["Sedang", "bg-warning"], ["Rendah", "bg-success"]].map(([l, c]) => (
                  <p key={l} className="flex items-center gap-2"><span className={`h-3 w-3 rounded-full ${c}`} /> {l}</p>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="panel p-4">
              <div className="mb-3 flex justify-between"><p className="font-semibold">Laporan Terbaru</p><a className="text-xs text-primary">Lihat Semua</a></div>
              <div className="space-y-3">
                {reports.map(([id, t, loc, lvl, time]) => (
                  <div key={id} className="flex gap-3">
                    <img src={fireImg} alt="" loading="lazy" className="h-14 w-16 rounded-md object-cover" />
                    <div className="flex-1 text-xs">
                      <p className="text-muted-foreground">{id}</p>
                      <p className={lvl === "Tinggi" ? "text-primary" : ""}>{t}</p>
                      <p className="text-muted-foreground">{loc}</p>
                    </div>
                    <div className="text-right text-[10px]">
                      <span className={`rounded px-2 py-0.5 ${badge[lvl]}`}>{lvl}</span>
                      <p className="mt-2 text-muted-foreground">{time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="panel p-4">
              <p className="font-semibold">Kondisi Cuaca</p>
              <p className="text-xs text-muted-foreground">Kalimantan Tengah</p>
              <div className="mt-3 flex items-center gap-4">
                <CloudSun className="h-10 w-10 text-warning" />
                <p className="text-3xl font-bold">32°C</p>
                <div className="ml-auto space-y-1 text-xs text-muted-foreground">
                  <p>Kelembapan <b className="text-foreground">62%</b></p>
                  <p>Curah Hujan <b className="text-foreground">0 mm</b></p>
                  <p>Angin <b className="text-foreground">12 km/j</b></p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="grid gap-4 xl:grid-cols-3">
          <div className="panel p-4">
            <div className="mb-4 flex items-center gap-2"><p className="font-semibold">Analisis AI</p><span className={`rounded px-2 text-xs ${badge["Tinggi"]}`}>Tinggi</span></div>
            <div className="flex gap-6">
              <div className="flex h-28 w-28 shrink-0 flex-col items-center justify-center rounded-full border-8 border-primary glow">
                <span className="text-3xl font-bold">87</span><span className="text-xs text-muted-foreground">/100</span>
              </div>
              <div className="flex-1 space-y-2 text-xs">
                {factors.map(([f, v]) => (
                  <div key={f}>
                    <div className="flex justify-between"><span>{f}</span><span>{v}%</span></div>
                    <div className="h-1.5 rounded bg-muted"><div className="h-full rounded bg-gradient-to-r from-primary to-accent" style={{ width: `${v}%` }} /></div>
                  </div>
                ))}
              </div>
            </div>
            <p className="mt-4 rounded-lg bg-muted p-3 text-xs"><b>Kesimpulan AI:</b> Terdapat indikasi kuat kebakaran lahan gambut. Disarankan verifikasi lapangan.</p>
          </div>

          <div className="panel p-4">
            <div className="mb-4 flex justify-between"><p className="font-semibold">Blockchain Audit</p><span className="flex items-center gap-1 text-xs text-success"><CheckCircle2 className="h-3 w-3" />Terverifikasi</span></div>
            <div className="space-y-4">
              {chain.map(([s, t, h]) => (
                <div key={s} className="flex items-center gap-3 text-sm">
                  <CheckCircle2 className="h-5 w-5 text-success" />
                  <div className="flex-1"><p>{s}</p><p className="text-xs text-muted-foreground">7 Sep 2026, {t}</p></div>
                  <code className="text-xs text-muted-foreground">{h}</code>
                </div>
              ))}
            </div>
          </div>

          <div className="panel p-4">
            <p className="font-semibold">Emisi yang Dihindari (Estimasi)</p>
            <p className="mt-2 text-2xl font-bold">12,500 tCO₂e <span className="text-sm text-success">↑ 32%</span></p>
            <div className="mt-4 flex h-32 items-end gap-2">
              {emissions.map((v, i) => <div key={i} className="flex-1 rounded-t bg-success" style={{ height: `${v}%` }} />)}
            </div>
          </div>
        </section>

        <section className="grid grid-cols-2 gap-4 xl:grid-cols-4">
          {[["Total Laporan", "1,248", "↑ 56%", "text-success"], ["Laporan Terverifikasi", "892", "↑ 42%", "text-success"], ["Luas Area Terdampak", "12,480 ha", "↓ 28%", "text-primary"], ["Respons Selesai", "76", "↑ 63%", "text-success"]].map(([l, v, d, c]) => (
            <div key={l} className="panel p-4"><p className="text-xs text-muted-foreground">{l}</p><p className="text-2xl font-bold">{v}</p><p className={`text-xs ${c}`}>{d}</p></div>
          ))}
        </section>
      </main>
    </div>
  );
}
